#ifndef _DRAWPOINT_H_
#define _DRAWPOINT_H_

#define PWIDTH 800  //屏幕宽度
#define PHIGH  480  //屏幕高度

void DrawPoint(int *py,int x, int y, int color);
// py     映射内存指针
// x      横坐标
// y      纵坐标
// color  颜色

#endif