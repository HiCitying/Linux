#ifndef _TOUCHSCREEN_H_
#define _TOUCHSCREEN_H_


#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <linux/input.h>
#include <stdio.h>

int TouchScreen(void);
//返回值滑动方向



#endif