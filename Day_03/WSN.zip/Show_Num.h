#ifndef _SHOW_NUM_H_
#define _SHOW_NUM_H_

void Show_Num(int num1,int *py,int x,int y,int color);

// num1 数组
// x
// y 初始位置


#endif