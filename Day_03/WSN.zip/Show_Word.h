#ifndef _SHOW_WORD_H_
#define _SHOW_WORD_H_

void Show_Word(char *word,int *py,int x, int y,int wide,int wordsize,int color);
// word     字符串指针
// py       映射操作符
// x        初始x位置
// y        初始y位置
// wide     生成字符位宽度
// wordsize 总字节数
// color    颜色

int WNum(int x);

#endif